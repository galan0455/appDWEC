var listacomidas=[]
var carrito=[];
$.getJSON("comidas.json",(datos)=>{
    listacomidas=datos
    pintarTablaComidas(listacomidas);
});
function pintarTablaComidas(){
    let divCentral=document.getElementById("central");
    let contenidoTabla="<table>"

    contenidoTabla += "<tbody>"
    listacomidas.forEach((comida)=>{

        contenidoTabla += "<tr>";
            for(propiedad in comida) 
            {
                contenidoTabla += "<td>"
                contenidoTabla += comida[propiedad]
                contenidoTabla += "</td>"
            }
            contenidoTabla += "<td>"
            contenidoTabla += `<button type='button' onclick='comprar(${comida.idComida})'>Comprar</button> `
            contenidoTabla += "</td>"
            contenidoTabla += "<td>"
            contenidoTabla += `<button type='button' onclick='quitar(${comida.idComida})'>Comprar</button> `
            contenidoTabla += "</td>"
        
    });
        contenidoTabla += "</tbody>"
        
    divCentral.innerHTML= contenidoTabla;
    
}
function comprar(idComida) {

    let posicion = carrito.findIndex((compra)=>compra.idComida == idComida)
    if (posicion!=-1) {
        carrito[posicion].cantidad++;
    }else{
        let compra ={
            "idComida":idComida,
            "cantidad":1
        }
        carrito.push(compra);
    }
    document.cookie="carrito=" + JSON.stringify(carrito);
    document.getElementById("contadorCarrito").innerHTML = carrito.length
}
function quitar(idComida) {
    let posicion = carrito.findIndex((compra)=>compra.idComida==idComida)
    if (posicion!=-1) {
        carrito[posicion].cantidad--;
    }else{
        
    }
}

function leerCarritoDeCookie(){
    let datosCookie=document.cookie.split(";");
    datosCookie.forEach((cookie)=>{
        let nombre = cookie.split("=")[0];
        let valor = cookie.split("=")[1];
        if (nombre=="carrito") {
            carrito = JSON.parse(valor)
        }
    })
    document.getElementById("contadorCarrito").innerHTML = carrito.length;
}
onload = ()=>{
    leerCarritoDeCookie();
}

// para casa que te muestre al pulsar el carrito un div abajo nombre del producto y la cantidad y el precio un boton para eliminar 