
    var listaZapatillas
    $.getJSON("ZapatillasJSON.json",(datos)=>{
        listaZapatillas=datos
        pintarZapatillas(listaZapatillas);
    });

    function pintarZapatillas() {
        let divDatos=document.getElementById("datos");
            divDatos.innerHTML += "<ul>"
        listaZapatillas.forEach((zapatillas) => {

            divDatos.innerHTML += zapatillas.Foto;
            divDatos.innerHTML+= "<li> Marca: "+zapatillas.marca+"</li>";
            divDatos.innerHTML+= "<li> Modelo: "+zapatillas.modelo+"</li>";
            divDatos.innerHTML+= "<li> Color: "+zapatillas.color+"</li>";
            divDatos.innerHTML+= "<li> stock: "+zapatillas.stock+"</li>";
            divDatos.innerHTML+= "<li> precio: "+zapatillas.precio+"</li>";
            
            
            
            exit;
            
        });
            divDatos.innerHTML += "</ul>"
    }
    function volver() {
        window.location.href="http://localhost:8080/aplicacion_Zapas_casa/aterrizaje.html";
    }