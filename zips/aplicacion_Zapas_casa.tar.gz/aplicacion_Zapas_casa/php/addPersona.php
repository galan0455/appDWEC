
<?php
    
$usuario = $_REQUEST["Usuario"];
$email = $_REQUEST["Email"];
$confemail = $_REQUEST["ConEmail"];
$contrasenia = $_REQUEST["Contraseña"];
$confcontrasenia = $_REQUEST["ConfContraseña"];
$open = fopen("../Usuarios.json","r");
$texto = fread($open, filesize("../Usuarios.json"));
$texto = str_replace("]",',{"Usuario":"'.$usuario.'","email":"'. $email.'","confemail":"'. $confemail.'","contraseña":"'. $contrasenia.'","confcontraseña":"'. $confcontrasenia.'"}',$texto);
$texto = $texto . "]";
fclose($open);
$open = fopen("../Usuarios.json","w+");
fwrite($open, $texto);
fclose($open);
print "<a href='../loggin.html'>Iniciar Sesion</a>"



?>
