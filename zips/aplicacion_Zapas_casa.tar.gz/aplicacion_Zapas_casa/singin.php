<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/loggin.css">
    
    <script src="./js/singin.js"></script>
</head>
<body>
    <form action="./php/addPersona.php" method="post">

        <section class="form-register">
            <input class="controls" type="text" name="Usuario" id="Usuario" placeholder="Ingrese su Usuario">
                <br>
            <input class="controls" type="email" name="Email" id="Email" placeholder="Ingrese su Correo">
                <br>
            <input class="controls" type="email" name="ConEmail" id="ConEmail" placeholder="Confirme Correo">
                <br>
            <input class="controls" type="password" name="Contraseña" id="Contraseña" placeholder="Ingrese la contraseña">
                <br>
            <input class="controls" type="password" name="ConfContraseña" id="ConfContraseña" placeholder="Confirme la contraseña">
                <br>
            <input class="bottons" type="submit" name="Registro" value="Registrate" id="Avanzar_inicioS">
            <input class="bottons" type="button" name="Volver_Aterrizaje" value="Volver a aterrizaje" id="volver_aterizaje">
        </section>
    </form>
</body>
</html>