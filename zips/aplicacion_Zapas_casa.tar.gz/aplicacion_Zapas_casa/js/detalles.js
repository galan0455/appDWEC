var listaZapatillas=[];
let idZapatilla = location.search.split("?")[1].split("=")[1];;
$.getJSON("ZapatillasJSON.json", (datos) => {
    listaZapatillas = datos;
    let posicion = listaZapatillas.findIndex((zapatilla)=>zapatilla.Id==  idZapatilla)
    pintarZapatilla(listaZapatillas[posicion]);
});

function pintarZapatilla(zapatilla) {
    let divDatos=document.getElementById("datos");
        divDatos.innerHTML += "<ul>"
        divDatos.innerHTML +=  "<img src="+zapatilla.Foto+">"
        divDatos.innerHTML+= "<li> Marca: "+zapatilla.marca+"</li>";
        divDatos.innerHTML+= "<li> Modelo: "+zapatilla.modelo+"</li>";
        divDatos.innerHTML+= "<li> Color: "+zapatilla.color+"</li>";
        divDatos.innerHTML+= "<li> stock: "+zapatilla.stock+"</li>";
        divDatos.innerHTML+= "<li> precio: "+zapatilla.precio+"</li>";        
        divDatos.innerHTML += "</ul>"
}
function volver() {
    window.location.href="http://localhost:8080/aplicacion_Zapas_casa/aterrizaje.html";
}
