    //Ejercicio 1 primero localizo la tabla y le añado el addevent listener 
    onload = ()=>{
        var listatd = [...document.getElementById("ruta").getElementsByTagName("td")];
        listatd.forEach((celda)=>{
        celda.addEventListener("click",pintar);
   })
    }
   
    
    
   function pintar(evento) {
        evento.target.parentNode.style.backgroundColor="blue";
        let columna=evento.target.cellIndex;

        let contador = 0; 

        while (contador< evento.target.parentNode.children.length && evento.target.parentNode.children[contador]!=evento.target) {
            contador++; 
        }
        var listatr = [...document.getElementById("ruta").getElementsByTagName("tr")];
        listatr.forEach((fila)=>{
            fila.children[columna].style.backgroundColor="red";
        })

   }

   // para el ejercicio de los checkbox buscar el cheked 

   //Para validar la fecha fecha=new Date(a,m,d)

   // if (fecha.getfull) para ver las fehcas buscar dia de las fechas entra seguro para el examen 