

    function comprobacionCampos() {
        
        let Email=document.getElementById("email") 
        let ConfEmail=document.getElementById("ConEmail")
        let Contraseña=document.getElementById("Contraseña")
        let ConfContraseña=document.getElementById("ConfContraseña")
         

    }