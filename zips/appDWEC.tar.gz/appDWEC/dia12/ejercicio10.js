var clave;
var direccion = "http://www.madrid.org"

function setClave() {
    clave = prompt("Dame una clave: ");
}