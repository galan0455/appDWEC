function miPrimeraFuncion(texto1, nombre) {
    document.write(texto1 + " " + nombre);
}