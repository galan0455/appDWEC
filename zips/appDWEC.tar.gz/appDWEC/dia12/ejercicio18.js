(function(a, b) {
    console.log(a);
    console.log(b);
})("HOLA", 123)