// archivo ejemplo.js
function miPrimeraFuncion(){
	alert("Hola mundo");
}