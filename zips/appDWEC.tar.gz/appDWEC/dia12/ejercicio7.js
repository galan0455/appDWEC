function potencia(x, n) {
    var resultado = 1;
    for (i = 0; i < n; i++) resultado = resultado * x;
    return resultado
}