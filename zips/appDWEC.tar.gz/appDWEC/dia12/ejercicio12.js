var cuadrado = function(numero) { return numero * numero; };
var x = cuadrado(5);
alert(x);