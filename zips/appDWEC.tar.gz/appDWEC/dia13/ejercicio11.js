// ejercicio 11: Sobreescribe el método volar del superheroe que no vuela para que se muestre
//    un mensaje que diga: "Este superheroe no vuela"

lobezno.volar= function(){     
    alert("No puede volar");
}

