    var listaCiudades = ['Avila','Barcelona','Burgos','Madrid','Toledo','Sevilla','Huelva','Valencia','Zaragoza']
        function marcarCelda(numero) {
            let celda=listaCiudades[numero];
            let Tabla = document.getElementById("ruta")
            console.log(Tabla.rows[0]);
            for (let i = 0; i < Tabla.rows.length; i++) {
                
            }
            

        }
    onload = ()=>{
        marcarCelda();
    }