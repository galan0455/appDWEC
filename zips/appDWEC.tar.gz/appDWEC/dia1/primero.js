

document.body.innerHTML+="<table><tbody>";
    for ( i = 0; i < 3; i++) {
    document.body.innerHTML+="<tr>"
    for ( j = 0; j < 3; i++) {
        document.body.innerHTML+="<td>X</td"      
    }
    document.body.innerHTML+="</tr>"
    }
document.body.innerHTML+="</table></tbody>"