<?php
    echo '{"IdPartida":1,"Premio":9, "NumCartones":10,"NumerosActuales":[10,2,3,8,55]}';
?>