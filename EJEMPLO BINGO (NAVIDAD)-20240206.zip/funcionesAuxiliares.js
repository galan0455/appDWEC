export function generaCartonAleatorio(){
    let carton=[2,7,12,33,49];

    return carton;
}